import requests

HUGGINGFACE_API_URL = "https://api-inference.huggingface.co/models/flax-community/t5-recipe-generation"
HUGGINGFACE_API_TOKEN = "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"

headers = {
    "Authorization": f"Bearer {HUGGINGFACE_API_TOKEN}",
    "Content-Type": "application/json"
}

def recip(ingredients, preference):
    if not ingredients.strip() or not preference.strip():
        return "Please enter both ingredients and dietary preference."

    prompt = f"ingredients: {ingredients}. preference: {preference}. generate a complete recipe."

    response = requests.post(HUGGINGFACE_API_URL, headers=headers, json={"inputs": prompt})

    if response.status_code == 200:
        result = response.json()
        # Debug print (optional): print(result)
        if isinstance(result, list):
            return result[0].get("generated_text", "No recipe generated.")
        elif isinstance(result, dict):
            return result.get("generated_text", "No recipe generated.")
        else:
            return "Unexpected response format."
    else:
        return f"Error {response.status_code}: {response.text}"
